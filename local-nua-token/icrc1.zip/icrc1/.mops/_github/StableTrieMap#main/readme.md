# StableTrieMap

A conversion of the TrieMap Class in the Motoko base library into a Stable module.
It has the exact same API as the the TrieMap class with a little more helper functions.

## Documentation
 > ToDo: Add documentation

#### Helper fns to add
- `putOrUpdate()`
- `containsKey()`
